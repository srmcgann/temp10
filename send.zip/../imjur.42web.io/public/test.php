<?php

$file = <<<'FILE'
TESTING....
FILE;
  file_put_contents('./test.html', $file);
?>